# Samvartha ∞ — master folder
Phase-by-phase build of the Samvartha personal AI OS (see docs/). APK is built by GitHub Actions (.github/workflows/build.yml).
Modules: `core/` (pure Kotlin: controller, mission state machine, tests) · `app/` (Android: Room, Compose).
Get the APK: GitHub → Actions → latest run → Artifacts → samvartha-debug-apk. Install it on the phone (allow "install unknown apps").
Status per phase: docs/CHECKLIST.md · Journal: docs/JOURNAL.md
