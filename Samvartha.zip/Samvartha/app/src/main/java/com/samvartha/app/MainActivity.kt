package com.samvartha.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.samvartha.app.ui.ChatScreen
import com.samvartha.app.ui.HomeScreen
import com.samvartha.app.ui.MissionsScreen
import com.samvartha.app.ui.SamvarthaTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SamvarthaTheme {
                var tab by rememberSaveable { mutableIntStateOf(0) }
                val titles = listOf("Home", "Chat", "Missions")
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar {
                            titles.forEachIndexed { i, t ->
                                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(t) })
                            }
                        }
                    },
                ) { pad ->
                    val m = Modifier.padding(pad)
                    androidx.compose.foundation.layout.Box(m) {
                        when (tab) {
                            0 -> HomeScreen(vm)
                            1 -> ChatScreen(vm)
                            else -> MissionsScreen(vm)
                        }
                    }
                }
            }
        }
    }
}
