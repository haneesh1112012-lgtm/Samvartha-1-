package com.samvartha.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.samvartha.app.data.MessageEntity
import com.samvartha.app.data.RoomMissionRepository
import com.samvartha.app.data.SamvarthaDatabase
import com.samvartha.app.data.toDomain
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import samvartha.core.controller.CentralController
import samvartha.core.controller.Mission
import samvartha.core.controller.MissionState
import samvartha.core.controller.Result

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = SamvarthaDatabase.get(app)
    private val controller = CentralController(RoomMissionRepository(db.missionDao(), db.eventDao()))
    private val clock = System::currentTimeMillis

    val missions: StateFlow<List<Mission>> = db.missionDao().observeAll()
        .map { list -> list.map { it.toDomain() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val messages: StateFlow<List<MessageEntity>> = db.messageDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _stopped = MutableStateFlow(controller.emergencyStopped)
    val stopped: StateFlow<Boolean> = _stopped

    private fun say(role: String, text: String) =
        db.messageDao().insert(MessageEntity(role = role, text = text, at = clock()))

    /** Phase 1: chat is persisted but no AI brain is connected yet (Phase 2/3). */
    fun sendChat(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            say("user", t)
            say("system", "No AI brain is connected yet (arrives in Phase 2). Your message is saved. " +
                "Use \"Mission\" to create a mission from it.")
        }
    }

    fun createMission(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            say("user", t)
            when (val r = controller.createMission(t)) {
                is Result.Err -> say("system", "Mission not created: ${r.message}")
                is Result.Ok -> {
                    // Planning/execution arrive in Phase 4; for now missions are queued and wait.
                    val q = controller.transition(r.value.id, MissionState.QUEUED, "queued on creation")
                    say("system", if (q is Result.Ok) "Mission queued (execution engine arrives in Phase 4)."
                    else "Mission created but could not be queued.")
                }
            }
        }
    }

    fun pause(id: String) = viewModelScope.launch(Dispatchers.IO) { controller.pause(id) }
    fun resume(id: String) = viewModelScope.launch(Dispatchers.IO) { controller.resume(id) }
    fun cancel(id: String) = viewModelScope.launch(Dispatchers.IO) { controller.cancel(id) }

    fun emergencyStop() {
        _stopped.value = true // UI reflects immediately; controller sets its own flag first thing on IO
        viewModelScope.launch(Dispatchers.IO) { controller.emergencyStop() } // Room writes must not run on main
    }

    fun clearEmergencyStop() { controller.clearEmergencyStop(); _stopped.value = false }
}
