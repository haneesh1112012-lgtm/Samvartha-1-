package com.samvartha.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MissionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) fun upsert(e: MissionEntity)
    @Query("SELECT * FROM missions WHERE id = :id") fun get(id: String): MissionEntity?
    @Query("SELECT * FROM missions ORDER BY createdAt DESC") fun all(): List<MissionEntity>
    @Query("SELECT * FROM missions ORDER BY createdAt DESC") fun observeAll(): Flow<List<MissionEntity>>
}

@Dao
interface EventDao {
    @Insert fun insert(e: MissionEventEntity)
    @Query("SELECT * FROM mission_events WHERE missionId = :missionId ORDER BY id ASC")
    fun forMission(missionId: String): List<MissionEventEntity>
}

@Dao
interface MessageDao {
    @Insert fun insert(e: MessageEntity)
    @Query("SELECT * FROM messages ORDER BY id ASC") fun observeAll(): Flow<List<MessageEntity>>
}
