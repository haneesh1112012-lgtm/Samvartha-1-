package com.samvartha.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey val id: String,
    val objective: String,
    val priority: Int,
    val state: String,
    val stateBeforePause: String?,
    val retryBudget: Int,
    val retriesUsed: Int,
    val blockReason: String?,
    val createdAt: Long,
    val updatedAt: Long,
)

@Entity(tableName = "mission_events", indices = [Index("missionId")])
data class MissionEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val missionId: String,
    val fromState: String?,
    val toState: String,
    val reason: String,
    val at: Long,
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" | "system"
    val text: String,
    val at: Long,
)
