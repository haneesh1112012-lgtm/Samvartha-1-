package com.samvartha.app.data

import samvartha.core.controller.Mission
import samvartha.core.controller.MissionEvent
import samvartha.core.controller.MissionRepository
import samvartha.core.controller.MissionState

fun MissionEntity.toDomain() = Mission(
    id = id, objective = objective, priority = priority,
    state = MissionState.valueOf(state),
    stateBeforePause = stateBeforePause?.let { MissionState.valueOf(it) },
    retryBudget = retryBudget, retriesUsed = retriesUsed, blockReason = blockReason,
    createdAt = createdAt, updatedAt = updatedAt,
)

fun Mission.toEntity() = MissionEntity(
    id = id, objective = objective, priority = priority, state = state.name,
    stateBeforePause = stateBeforePause?.name, retryBudget = retryBudget,
    retriesUsed = retriesUsed, blockReason = blockReason, createdAt = createdAt, updatedAt = updatedAt,
)

/** Blocking calls: invoke only from Dispatchers.IO. */
class RoomMissionRepository(
    private val missions: MissionDao,
    private val events: EventDao,
) : MissionRepository {
    override fun save(mission: Mission) = missions.upsert(mission.toEntity())
    override fun get(id: String): Mission? = missions.get(id)?.toDomain()
    override fun all(): List<Mission> = missions.all().map { it.toDomain() }
    override fun appendEvent(event: MissionEvent) = events.insert(
        MissionEventEntity(
            missionId = event.missionId, fromState = event.from?.name,
            toState = event.to.name, reason = event.reason, at = event.at,
        )
    )
    override fun events(missionId: String): List<MissionEvent> =
        events.forMission(missionId).map {
            MissionEvent(it.missionId, it.fromState?.let { s -> MissionState.valueOf(s) },
                MissionState.valueOf(it.toState), it.reason, it.at)
        }
}
