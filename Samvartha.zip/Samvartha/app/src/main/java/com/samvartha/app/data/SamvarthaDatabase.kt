package com.samvartha.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

// TODO(Phase 12 / before any schema change): export schemas and add versioned Migrations.
@Database(
    entities = [MissionEntity::class, MissionEventEntity::class, MessageEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class SamvarthaDatabase : RoomDatabase() {
    abstract fun missionDao(): MissionDao
    abstract fun eventDao(): EventDao
    abstract fun messageDao(): MessageDao

    companion object {
        @Volatile private var instance: SamvarthaDatabase? = null
        fun get(context: Context): SamvarthaDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, SamvarthaDatabase::class.java, "samvartha.db"
            ).build().also { instance = it }
        }
    }
}
