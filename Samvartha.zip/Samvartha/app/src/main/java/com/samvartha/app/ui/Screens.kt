package com.samvartha.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.samvartha.app.MainViewModel
import samvartha.core.controller.Mission
import samvartha.core.controller.MissionState
import samvartha.core.controller.MissionTransitions

@Composable
fun HomeScreen(vm: MainViewModel) {
    val missions by vm.missions.collectAsStateWithLifecycle()
    val stopped by vm.stopped.collectAsStateWithLifecycle()
    val total = missions.size
    val active = missions.count { !it.state.isTerminal }
    val completed = missions.count { it.state == MissionState.COMPLETED }
    val failed = missions.count { it.state == MissionState.FAILED }
    val cancelled = missions.count { it.state == MissionState.CANCELLED }
    val paused = missions.count { it.state == MissionState.PAUSED }
    val rate = if (completed + failed == 0) "n/a" else "${completed * 100 / (completed + failed)}%"

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("SAMVARTHA ∞", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Crimson) }
        item { Text("Phase 1 · foundation", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            if (stopped) {
                Card(colors = CardDefaults.cardColors(containerColor = CrimsonDark), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("EMERGENCY STOP ACTIVE", fontWeight = FontWeight.Bold)
                        Text("All active missions were paused. New work is blocked.")
                        OutlinedButton(onClick = vm::clearEmergencyStop, modifier = Modifier.padding(top = 8.dp)) {
                            Text("Clear emergency stop")
                        }
                    }
                }
            } else {
                Button(
                    onClick = vm::emergencyStop,
                    colors = ButtonDefaults.buttonColors(containerColor = Crimson),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("EMERGENCY STOP", fontWeight = FontWeight.Bold) }
            }
        }
        item { StatCard("Brains", listOf("Ollama (local): not connected (Phase 2)", "Gemini (browser): not connected (Phase 3)")) }
        item {
            StatCard("Missions", listOf(
                "Total: $total   Active: $active   Paused: $paused",
                "Completed: $completed   Failed: $failed   Cancelled: $cancelled",
                "Success rate: $rate",
            ))
        }
        item { StatCard("Not yet available", listOf("Approvals, resource monitor, executors, memory dashboards: later phases")) }
    }
}

@Composable
private fun StatCard(title: String, lines: List<String>) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Crimson)
            lines.forEach { Text(it) }
        }
    }
}

@Composable
fun ChatScreen(vm: MainViewModel) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size) { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }

    Column(Modifier.fillMaxSize().imePadding().padding(12.dp)) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { m ->
                val mine = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text,
                        modifier = Modifier
                            .background(if (mine) CrimsonDark else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
                            .padding(12.dp),
                    )
                }
            }
        }
        OutlinedTextField(
            value = input, onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            placeholder = { Text("Type a message or a mission objective") },
        )
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.sendChat(input); input = "" }, modifier = Modifier.weight(1f)) { Text("Send") }
            Button(
                onClick = { vm.createMission(input); input = "" },
                colors = ButtonDefaults.buttonColors(containerColor = Crimson),
                modifier = Modifier.weight(1f),
            ) { Text("Mission") }
        }
    }
}

@Composable
fun MissionsScreen(vm: MainViewModel) {
    val missions by vm.missions.collectAsStateWithLifecycle()
    if (missions.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No missions yet. Create one from Chat.") }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(missions, key = { it.id }) { m -> MissionCard(m, vm) }
    }
}

@Composable
private fun MissionCard(m: Mission, vm: MainViewModel) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(m.objective, fontWeight = FontWeight.SemiBold)
            Text("State: ${m.state}   Priority: ${m.priority}", color = Crimson)
            m.blockReason?.let { Text("Blocked: $it") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (MissionTransitions.canTransition(m.state, MissionState.PAUSED))
                    OutlinedButton(onClick = { vm.pause(m.id) }) { Text("Pause") }
                if (m.state == MissionState.PAUSED)
                    OutlinedButton(onClick = { vm.resume(m.id) }) { Text("Resume") }
                if (!m.state.isTerminal)
                    OutlinedButton(onClick = { vm.cancel(m.id) }) { Text("Cancel") }
            }
        }
    }
}
