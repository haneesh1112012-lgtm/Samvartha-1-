package com.samvartha.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Crimson = Color(0xFFB3122D)
val CrimsonDark = Color(0xFF6E0A1B)
val SurfaceDark = Color(0xFF0F0F12)

private val scheme = darkColorScheme(
    primary = Crimson, onPrimary = Color.White,
    secondary = CrimsonDark, onSecondary = Color.White,
    background = Color.Black, onBackground = Color(0xFFEDEDED),
    surface = SurfaceDark, onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF1A1A1F), onSurfaceVariant = Color(0xFFB8B8C0),
    error = Color(0xFFFF4D5E),
)

@Composable
fun SamvarthaTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = scheme, content = content)
