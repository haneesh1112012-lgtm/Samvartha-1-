package samvartha.core.common

/** Injectable time source so state logic is deterministic in tests. */
fun interface Clock { fun nowMillis(): Long }
object SystemClock : Clock { override fun nowMillis() = System.currentTimeMillis() }
