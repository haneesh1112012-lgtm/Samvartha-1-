package samvartha.core.controller

import samvartha.core.common.Clock
import samvartha.core.common.SystemClock
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

sealed interface Result<out T> {
    data class Ok<T>(val value: T) : Result<T>
    data class Err(val message: String) : Result<Nothing>
}

/**
 * Single mission controller (spec Part 7). Phase 1 scope: validated creation,
 * guarded transitions, pause/resume/cancel, bounded retries, and a
 * model-independent emergency stop. Later phases must go through [transition].
 */
class CentralController(
    private val repo: MissionRepository,
    private val clock: Clock = SystemClock,
    private val idGen: () -> String = { UUID.randomUUID().toString() },
) {
    private val stopped = AtomicBoolean(false)
    val emergencyStopped: Boolean get() = stopped.get()

    fun createMission(objective: String, priority: Int = 5): Result<Mission> {
        if (stopped.get()) return Result.Err("Emergency stop active")
        val text = objective.trim()
        if (text.length < 3) return Result.Err("Objective too short")
        if (text.length > 4000) return Result.Err("Objective too long")
        if (priority !in 1..10) return Result.Err("Priority must be 1..10")
        val now = clock.nowMillis()
        val m = Mission(idGen(), text, priority, MissionState.CREATED, createdAt = now, updatedAt = now)
        repo.save(m)
        repo.appendEvent(MissionEvent(m.id, null, m.state, "created", now))
        return Result.Ok(m)
    }

    fun transition(id: String, to: MissionState, reason: String): Result<Mission> {
        val m = repo.get(id) ?: return Result.Err("Unknown mission $id")
        if (stopped.get() && to != MissionState.CANCELLED && to != MissionState.PAUSED)
            return Result.Err("Emergency stop active")
        if (!MissionTransitions.canTransition(m.state, to))
            return Result.Err("Illegal transition ${m.state} -> $to")
        if (to == MissionState.BLOCKED && reason.isBlank()) return Result.Err("BLOCKED requires a reason")
        return Result.Ok(apply(m, to, reason))
    }

    fun pause(id: String): Result<Mission> {
        val m = repo.get(id) ?: return Result.Err("Unknown mission $id")
        if (!MissionTransitions.canTransition(m.state, MissionState.PAUSED))
            return Result.Err("Cannot pause from ${m.state}")
        return Result.Ok(apply(m.copy(stateBeforePause = m.state), MissionState.PAUSED, "paused by user"))
    }

    fun resume(id: String): Result<Mission> {
        if (stopped.get()) return Result.Err("Emergency stop active")
        val m = repo.get(id) ?: return Result.Err("Unknown mission $id")
        if (m.state != MissionState.PAUSED) return Result.Err("Not paused")
        // Resume re-queues; the engine re-validates rather than trusting a stale state.
        return Result.Ok(apply(m.copy(stateBeforePause = null), MissionState.QUEUED, "resumed by user"))
    }

    fun cancel(id: String): Result<Mission> = transition(id, MissionState.CANCELLED, "cancelled by user")

    /** Recovery bookkeeping: bounded retries, then FAILED. */
    fun recordFailureAndRecover(id: String, reason: String): Result<Mission> {
        val m = repo.get(id) ?: return Result.Err("Unknown mission $id")
        val used = m.retriesUsed + 1
        val target = if (used > m.retryBudget) MissionState.FAILED else MissionState.RECOVERING
        if (!MissionTransitions.canTransition(m.state, target)) return Result.Err("Cannot $target from ${m.state}")
        return Result.Ok(apply(m.copy(retriesUsed = used), target, reason))
    }

    /** Deterministic; touches no model. Pauses every non-terminal mission and blocks further work. */
    fun emergencyStop(): Int {
        stopped.set(true)
        var n = 0
        for (m in repo.all()) {
            if (m.state.isTerminal || m.state == MissionState.PAUSED) continue
            if (MissionTransitions.canTransition(m.state, MissionState.PAUSED)) {
                apply(m.copy(stateBeforePause = m.state), MissionState.PAUSED, "EMERGENCY STOP"); n++
            } else {
                apply(m, MissionState.CANCELLED, "EMERGENCY STOP (cannot pause)"); n++
            }
        }
        return n
    }

    fun clearEmergencyStop() { stopped.set(false) }

    private fun apply(m: Mission, to: MissionState, reason: String): Mission {
        val now = clock.nowMillis()
        val updated = m.copy(state = to, updatedAt = now, blockReason = if (to == MissionState.BLOCKED) reason else null)
        repo.save(updated)
        repo.appendEvent(MissionEvent(m.id, m.state, to, reason, now))
        return updated
    }
}
