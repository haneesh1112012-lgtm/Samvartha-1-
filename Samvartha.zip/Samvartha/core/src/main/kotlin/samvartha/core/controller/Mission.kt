package samvartha.core.controller

data class Mission(
    val id: String,
    val objective: String,
    val priority: Int,
    val state: MissionState,
    val stateBeforePause: MissionState? = null,
    val retryBudget: Int = 3,
    val retriesUsed: Int = 0,
    val blockReason: String? = null,
    val createdAt: Long,
    val updatedAt: Long,
)

data class MissionEvent(val missionId: String, val from: MissionState?, val to: MissionState, val reason: String, val at: Long)
