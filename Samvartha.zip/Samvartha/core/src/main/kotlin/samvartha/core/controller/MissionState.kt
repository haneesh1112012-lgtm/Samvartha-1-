package samvartha.core.controller

import samvartha.core.controller.MissionState.*

/** Mission lifecycle states from spec Part 8. */
enum class MissionState {
    CREATED, QUEUED, ANALYZING, PLANNING, READY, EXECUTING, OBSERVING, VERIFYING,
    RECOVERING, AWAITING_APPROVAL, PAUSED, BLOCKED, COMPLETED, FAILED, CANCELLED;

    val isTerminal: Boolean get() = this == COMPLETED || this == FAILED || this == CANCELLED
}

/** Single source of truth for which transitions are legal. */
object MissionTransitions {
    private val table: Map<MissionState, Set<MissionState>> = run {
        mapOf(
            CREATED to setOf(QUEUED, CANCELLED, BLOCKED),
            QUEUED to setOf(ANALYZING, PAUSED, CANCELLED, BLOCKED),
            ANALYZING to setOf(PLANNING, BLOCKED, AWAITING_APPROVAL, PAUSED, FAILED, CANCELLED),
            PLANNING to setOf(READY, BLOCKED, AWAITING_APPROVAL, PAUSED, FAILED, CANCELLED),
            READY to setOf(EXECUTING, AWAITING_APPROVAL, PAUSED, CANCELLED),
            EXECUTING to setOf(OBSERVING, RECOVERING, AWAITING_APPROVAL, PAUSED, FAILED, CANCELLED),
            OBSERVING to setOf(VERIFYING, RECOVERING, PAUSED, FAILED, CANCELLED),
            // COMPLETED is reachable ONLY via VERIFYING: unverified work is never "done".
            VERIFYING to setOf(COMPLETED, RECOVERING, EXECUTING, PAUSED, FAILED, CANCELLED),
            RECOVERING to setOf(EXECUTING, PLANNING, BLOCKED, FAILED, PAUSED, CANCELLED),
            AWAITING_APPROVAL to setOf(READY, EXECUTING, CANCELLED, PAUSED),
            PAUSED to setOf(QUEUED, READY, EXECUTING, CANCELLED),
            BLOCKED to setOf(QUEUED, PLANNING, CANCELLED),
            COMPLETED to emptySet(), FAILED to emptySet(), CANCELLED to emptySet()
        ).also { m -> check(m.keys == MissionState.values().toSet()) }
    }
    fun canTransition(from: MissionState, to: MissionState) = to in table.getValue(from)
    fun allowedFrom(from: MissionState): Set<MissionState> = table.getValue(from)
}
