package samvartha.core.controller

/** Persistence port. Android module supplies a Room implementation. */
interface MissionRepository {
    fun save(mission: Mission)
    fun get(id: String): Mission?
    fun all(): List<Mission>
    fun appendEvent(event: MissionEvent)
    fun events(missionId: String): List<MissionEvent>
}

class InMemoryMissionRepository : MissionRepository {
    private val missions = LinkedHashMap<String, Mission>()
    private val log = ArrayList<MissionEvent>()
    @Synchronized override fun save(mission: Mission) { missions[mission.id] = mission }
    @Synchronized override fun get(id: String) = missions[id]
    @Synchronized override fun all() = missions.values.toList()
    @Synchronized override fun appendEvent(event: MissionEvent) { log += event }
    @Synchronized override fun events(missionId: String) = log.filter { it.missionId == missionId }
}
