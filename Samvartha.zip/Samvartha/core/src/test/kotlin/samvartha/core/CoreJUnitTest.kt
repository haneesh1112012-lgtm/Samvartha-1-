package samvartha.core

import org.junit.Assert.assertTrue
import org.junit.Test

class CoreJUnitTest {
    @Test fun allCoreTestsPass() {
        val failed = runAll()
        assertTrue("Failing core tests: $failed", failed.isEmpty())
    }
}
