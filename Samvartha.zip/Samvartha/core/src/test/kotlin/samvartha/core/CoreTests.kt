package samvartha.core

import samvartha.core.common.Clock
import samvartha.core.controller.*
import kotlin.system.exitProcess

// No JUnit available offline (Maven blocked); minimal harness. Same assertions port 1:1 to JUnit in the Android module.
private var passed = 0
private var failures = ArrayList<String>()
private fun test(name: String, body: () -> Unit) {
    try { body(); passed++; println("PASS  $name") }
    catch (t: Throwable) { failures += name; println("FAIL  $name -> ${t.message}") }
}
private fun expect(c: Boolean, msg: String) { if (!c) throw AssertionError(msg) }

private class FakeClock : Clock { var t = 1000L; override fun nowMillis() = t++ }
private fun ctl(repo: MissionRepository = InMemoryMissionRepository()): Pair<CentralController, MissionRepository> {
    var n = 0
    return CentralController(repo, FakeClock(), { "m${n++}" }) to repo
}
private fun mk(c: CentralController, text: String = "research interior design firms") =
    (c.createMission(text) as Result.Ok).value
private fun walk(c: CentralController, id: String, vararg s: MissionState) =
    s.forEach { expect(c.transition(id, it, "step") is Result.Ok, "should reach $it") }

fun runAll(): List<String> {
    passed = 0; failures = ArrayList()
    test("create mission persists with CREATED state and event") {
        val (c, r) = ctl(); val m = mk(c)
        expect(r.get(m.id)?.state == MissionState.CREATED, "state")
        expect(r.events(m.id).size == 1, "event logged")
    }
    test("create rejects short, long, bad priority") {
        val (c, _) = ctl()
        expect(c.createMission("  a ") is Result.Err, "short")
        expect(c.createMission("x".repeat(4001)) is Result.Err, "long")
        expect(c.createMission("valid objective", 11) is Result.Err, "priority")
    }
    test("objective is trimmed") {
        val (c, _) = ctl(); expect(mk(c, "  hello world  ").objective == "hello world", "trim")
    }
    test("happy path reaches COMPLETED via VERIFYING") {
        val (c, _) = ctl(); val m = mk(c)
        walk(c, m.id, MissionState.QUEUED, MissionState.ANALYZING, MissionState.PLANNING, MissionState.READY,
            MissionState.EXECUTING, MissionState.OBSERVING, MissionState.VERIFYING, MissionState.COMPLETED)
    }
    test("unverified work cannot complete") {
        val (c, _) = ctl(); val m = mk(c)
        walk(c, m.id, MissionState.QUEUED, MissionState.ANALYZING, MissionState.PLANNING, MissionState.READY, MissionState.EXECUTING)
        expect(c.transition(m.id, MissionState.COMPLETED, "skip") is Result.Err, "EXECUTING->COMPLETED must fail")
        walk(c, m.id, MissionState.OBSERVING)
        expect(c.transition(m.id, MissionState.COMPLETED, "skip") is Result.Err, "OBSERVING->COMPLETED must fail")
    }
    test("no state may transition into COMPLETED except VERIFYING") {
        for (s in MissionState.values()) if (s != MissionState.VERIFYING)
            expect(!MissionTransitions.canTransition(s, MissionState.COMPLETED), "$s -> COMPLETED")
    }
    test("terminal states have no exits") {
        for (s in MissionState.values().filter { it.isTerminal }) expect(MissionTransitions.allowedFrom(s).isEmpty(), "$s")
    }
    test("illegal transition rejected and state unchanged") {
        val (c, r) = ctl(); val m = mk(c)
        expect(c.transition(m.id, MissionState.EXECUTING, "x") is Result.Err, "illegal")
        expect(r.get(m.id)!!.state == MissionState.CREATED, "unchanged")
    }
    test("BLOCKED requires reason and stores it") {
        val (c, r) = ctl(); val m = mk(c)
        expect(c.transition(m.id, MissionState.BLOCKED, " ") is Result.Err, "blank reason")
        c.transition(m.id, MissionState.BLOCKED, "unsupported task")
        expect(r.get(m.id)!!.blockReason == "unsupported task", "reason")
    }
    test("unknown mission id yields error") {
        val (c, _) = ctl(); expect(c.pause("nope") is Result.Err, "unknown")
    }
    test("pause then resume re-queues") {
        val (c, r) = ctl(); val m = mk(c); walk(c, m.id, MissionState.QUEUED)
        expect(c.pause(m.id) is Result.Ok && r.get(m.id)!!.state == MissionState.PAUSED, "paused")
        expect(c.resume(m.id) is Result.Ok && r.get(m.id)!!.state == MissionState.QUEUED, "resumed")
    }
    test("resume of non-paused fails") {
        val (c, _) = ctl(); val m = mk(c); expect(c.resume(m.id) is Result.Err, "not paused")
    }
    test("cancel works and is terminal") {
        val (c, _) = ctl(); val m = mk(c); c.cancel(m.id)
        expect(c.transition(m.id, MissionState.QUEUED, "again") is Result.Err, "terminal")
    }
    test("retries are bounded then FAILED") {
        val (c, r) = ctl(); val m = mk(c)
        walk(c, m.id, MissionState.QUEUED, MissionState.ANALYZING, MissionState.PLANNING, MissionState.READY, MissionState.EXECUTING)
        for (i in 1..3) {
            expect(c.recordFailureAndRecover(m.id, "err$i") is Result.Ok, "recover $i")
            expect(r.get(m.id)!!.state == MissionState.RECOVERING, "RECOVERING $i")
            walk(c, m.id, MissionState.EXECUTING)
        }
        c.recordFailureAndRecover(m.id, "err4")
        expect(r.get(m.id)!!.state == MissionState.FAILED, "FAILED after budget")
    }
    test("emergency stop pauses active missions, spares terminal, blocks new work") {
        val (c, r) = ctl()
        val a = mk(c); walk(c, a.id, MissionState.QUEUED, MissionState.ANALYZING)
        val b = mk(c); c.cancel(b.id)
        val d = mk(c)
        val n = c.emergencyStop()
        expect(n == 2, "affected=$n")
        expect(r.get(a.id)!!.state == MissionState.PAUSED, "a paused")
        expect(r.get(b.id)!!.state == MissionState.CANCELLED, "b untouched")
        expect(r.get(d.id)!!.state == MissionState.CANCELLED || r.get(d.id)!!.state == MissionState.PAUSED, "d halted")
        expect(c.createMission("new work here") is Result.Err, "no new missions")
        expect(c.resume(a.id) is Result.Err, "no resume")
        expect(c.transition(a.id, MissionState.EXECUTING, "x") is Result.Err, "no execute")
    }
    test("emergency stop can be cleared explicitly") {
        val (c, _) = ctl(); c.emergencyStop(); c.clearEmergencyStop()
        expect(c.createMission("work after clear") is Result.Ok, "works again")
    }
    test("event log records every transition in order") {
        val (c, r) = ctl(); val m = mk(c); walk(c, m.id, MissionState.QUEUED, MissionState.ANALYZING)
        val ev = r.events(m.id)
        expect(ev.map { it.to } == listOf(MissionState.CREATED, MissionState.QUEUED, MissionState.ANALYZING), "order ${ev.map { it.to }}")
    }
    println("\n$passed passed, ${failures.size} failed")
    return failures
}

fun main() { if (runAll().isNotEmpty()) exitProcess(1) }
