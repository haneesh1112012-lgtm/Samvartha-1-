# Implementation checklist
Legend: [x] verified, [~] written, NOT yet compiled (awaiting first GitHub Actions run), [ ] todo
## Phase 1 — Foundation
- [x] Mission states + guarded transitions (core, tested: 17/17 via kotlinc)
- [x] CentralController: validated create, pause/resume/cancel, bounded retries, emergency stop
- [x] Repository port + in-memory impl
- [~] Gradle project (AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06, Room 2.6.1 + KSP), manifest, theme
- [~] Room DB + RoomMissionRepository, conversation persistence
- [~] Compose shell: Home dashboard (real counts, emergency stop), Chat (persisted), Missions (pause/resume/cancel)
- [~] GitHub Actions: core tests + debug APK artifact
- [ ] Instrumented persistence-across-restart test (needs emulator; not in CI yet)
- [ ] Transaction-safe save+event write; Room migrations/schema export
- [ ] Phase 1 gate: CI green (core tests + assembleDebug) and APK launches on device
## Phases 2-12: not started
