# Environment inspection (2026-11-05, Claude sandbox)
- Ubuntu 24.04 x86_64, 1 CPU, 3.9 GB RAM, ~10 GB free disk. NOT an Android device (no ARM64, no Termux).
- Present: OpenJDK 21 runtime, git, python 3.12, node 22. Installed this session: openjdk-21-jdk-headless, Kotlin 2.0.21 (from GitHub release).
- Missing: Gradle, Android SDK, adb, sdkmanager.
- Network allowlist blocks dl.google.com, services.gradle.org, repo.maven.apache.org, maven.google.com, plugins.gradle.org.
  => Android Gradle Plugin, Compose, Room, Coroutines and JUnit cannot be downloaded. A Compose/Room APK CANNOT be built here.
- Not testable here: Ollama, Playwright-on-ARM64, AccessibilityService, speech, device RAM/thermal/battery.
