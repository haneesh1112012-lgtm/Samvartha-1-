# Development journal
## 2026-11-05 — Milestone 0/1a
Created: core/ (Clock, MissionState, Mission, Repositories, CentralController), core tests, docs.
Build: kotlinc 2.0.21 compiled main + tests: OK (one real error fixed: enum aliasing).
Tests: 17 passed, 0 failed (custom harness; JUnit unavailable offline).
Known: no Android module, no APK, no Room, no UI. Phase 1 is NOT complete.
Decision: keep core as pure Kotlin/JVM so it stays testable anywhere; Android module depends on it.

## 2026-11-05 — Milestone 1b (Android shell)
Created: settings/build gradle files, core/build.gradle.kts, core JUnit wrapper, app/ (manifest, theme, Room entities/DAOs/DB/repository, MainViewModel, Compose screens, MainActivity), .github/workflows/build.yml, README.
Verified here: XML well-formed; core still compiles and 17/17 tests pass.
NOT verified: any Android code (no SDK in sandbox). First CI run is the real compile check; fix errors from its log.
Known: emergency stop flag is in-memory (resets on process restart; paused state persists). save+appendEvent not in one transaction. Chat has no AI brain (Phase 2).
